--Made by Alina!!--
vanilla_model.ARMOR:setVisible(false)

vanilla_model.CAPE:setVisible(false)

vanilla_model.PLAYER:setVisible(false)

local squapi = require("SquAPI")

--replace each nil with the value/parmater you want to use, or leave as nil to use default values :)
--parenthesis are default values for reference
squapi.ear:new(
    models.exampleModel.exampleLeftEar, --leftEar
    nil, --(nil) rightEar
    0.5, --(1) rangeMultiplier
    nil, --(false) horizontalEars
    nil, --(2) bendStrength
    false, --(true) doEarFlick
    nil, --(400) earFlickChance
    nil, --(0.1) earStiffness
    nil  --(0.8) earBounce
)
--this runs ear with only one ear and no second ear, sets the range to 0.5, and disables ear flick

