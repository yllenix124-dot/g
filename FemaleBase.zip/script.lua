--Made by Alina!!--
vanilla_model.ARMOR:setVisible(false)

vanilla_model.CAPE:setVisible(false)

vanilla_model.PLAYER:setVisible(false)
